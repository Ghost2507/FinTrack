const express = require('express');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/users/dashboard
// @desc    Get user dashboard data
// @access  Private
router.get('/dashboard', auth, async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    // Get current month transactions
    const currentMonthTransactions = await Transaction.find({
      user: req.user._id,
      isActive: true,
      date: { $gte: startOfMonth, $lte: endOfMonth }
    });

    // Calculate totals
    const totalIncome = currentMonthTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalExpenses = currentMonthTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    const netAmount = totalIncome - totalExpenses;
    const budgetRemaining = req.user.monthlyBudget - totalExpenses;
    const budgetUsedPercentage = req.user.monthlyBudget > 0 
      ? (totalExpenses / req.user.monthlyBudget) * 100 
      : 0;

    // Get recent transactions (last 10)
    const recentTransactions = await Transaction.find({
      user: req.user._id,
      isActive: true
    })
    .sort({ date: -1 })
    .limit(10)
    .select('type amount description category date');

    // Get category breakdown for expenses
    const categoryBreakdown = await Transaction.aggregate([
      {
        $match: {
          user: req.user._id,
          isActive: true,
          type: 'expense',
          date: { $gte: startOfMonth, $lte: endOfMonth }
        }
      },
      {
        $group: {
          _id: '$category',
          total: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      },
      { $sort: { total: -1 } },
      { $limit: 5 }
    ]);

    // Get monthly trend (last 6 months)
    const monthlyTrend = await Transaction.aggregate([
      {
        $match: {
          user: req.user._id,
          isActive: true,
          date: { $gte: new Date(now.getFullYear(), now.getMonth() - 5, 1) }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$date' },
            month: { $month: '$date' },
            type: '$type'
          },
          total: { $sum: '$amount' }
        }
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } }
    ]);

    // Format monthly trend data
    const trendData = {};
    monthlyTrend.forEach(item => {
      const key = `${item._id.year}-${item._id.month.toString().padStart(2, '0')}`;
      if (!trendData[key]) {
        trendData[key] = { income: 0, expenses: 0 };
      }
      trendData[key][item._id.type] = item.total;
    });

    const monthlyTrendArray = Object.keys(trendData).map(key => ({
      month: key,
      income: trendData[key].income,
      expenses: trendData[key].expenses
    }));

    res.json({
      user: {
        name: req.user.name,
        monthlyBudget: req.user.monthlyBudget,
        currency: req.user.currency
      },
      currentMonth: {
        totalIncome,
        totalExpenses,
        netAmount,
        budgetRemaining,
        budgetUsedPercentage: Math.round(budgetUsedPercentage * 100) / 100,
        transactionCount: currentMonthTransactions.length
      },
      recentTransactions,
      categoryBreakdown,
      monthlyTrend: monthlyTrendArray
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ message: 'Server error while fetching dashboard data' });
  }
});

// @route   GET /api/users/categories
// @desc    Get user's transaction categories
// @access  Private
router.get('/categories', auth, async (req, res) => {
  try {
    const categories = await Transaction.aggregate([
      {
        $match: {
          user: req.user._id,
          isActive: true
        }
      },
      {
        $group: {
          _id: {
            category: '$category',
            type: '$type'
          },
          count: { $sum: 1 },
          totalAmount: { $sum: '$amount' }
        }
      },
      {
        $group: {
          _id: '$_id.category',
          types: {
            $push: {
              type: '$_id.type',
              count: '$count',
              totalAmount: '$totalAmount'
            }
          }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({ categories });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ message: 'Server error while fetching categories' });
  }
});

module.exports = router;
