const express = require('express');
const { body, validationResult, query } = require('express-validator');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/transactions
// @desc    Get user's transactions with filtering and pagination
// @access  Private
router.get('/', auth, [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('type').optional().isIn(['income', 'expense']).withMessage('Type must be income or expense'),
  query('category').optional().trim().isLength({ min: 1, max: 50 }).withMessage('Category must be 1-50 characters'),
  query('startDate').optional().isISO8601().withMessage('Start date must be valid ISO date'),
  query('endDate').optional().isISO8601().withMessage('End date must be valid ISO date')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    // Build filter object
    const filter = { user: req.user._id, isActive: true };
    
    if (req.query.type) filter.type = req.query.type;
    if (req.query.category) filter.category = new RegExp(req.query.category, 'i');
    
    if (req.query.startDate || req.query.endDate) {
      filter.date = {};
      if (req.query.startDate) filter.date.$gte = new Date(req.query.startDate);
      if (req.query.endDate) filter.date.$lte = new Date(req.query.endDate);
    }

    const transactions = await Transaction.find(filter)
      .sort({ date: -1 })
      .skip(skip)
      .limit(limit)
      .populate('user', 'name email');

    const total = await Transaction.countDocuments(filter);
    const totalPages = Math.ceil(total / limit);

    res.json({
      transactions,
      pagination: {
        currentPage: page,
        totalPages,
        totalTransactions: total,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    res.status(500).json({ message: 'Server error while fetching transactions' });
  }
});

// @route   POST /api/transactions
// @desc    Create a new transaction
// @access  Private
router.post('/', auth, [
  body('type').isIn(['income', 'expense']).withMessage('Type must be income or expense'),
  body('amount').isFloat({ min: 0.01 }).withMessage('Amount must be greater than 0'),
  body('description').trim().isLength({ min: 1, max: 200 }).withMessage('Description must be 1-200 characters'),
  body('category').trim().isLength({ min: 1, max: 50 }).withMessage('Category must be 1-50 characters'),
  body('subcategory').optional().trim().isLength({ max: 50 }).withMessage('Subcategory cannot exceed 50 characters'),
  body('paymentMethod').optional().isIn(['cash', 'card', 'upi', 'netbanking', 'wallet', 'other']).withMessage('Invalid payment method'),
  body('tags').optional().isArray().withMessage('Tags must be an array'),
  body('location').optional().trim().isLength({ max: 100 }).withMessage('Location cannot exceed 100 characters'),
  body('notes').optional().trim().isLength({ max: 500 }).withMessage('Notes cannot exceed 500 characters'),
  body('date').optional().isISO8601().withMessage('Date must be valid ISO date'),
  body('isRecurring').optional().isBoolean().withMessage('isRecurring must be boolean'),
  body('recurringPattern').optional().isIn(['daily', 'weekly', 'monthly', 'yearly']).withMessage('Invalid recurring pattern')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const transactionData = {
      ...req.body,
      user: req.user._id
    };

    // Validate recurring transaction
    if (transactionData.isRecurring && !transactionData.recurringPattern) {
      return res.status(400).json({ 
        message: 'Recurring pattern is required for recurring transactions' 
      });
    }

    const transaction = new Transaction(transactionData);
    await transaction.save();

    res.status(201).json({
      message: 'Transaction created successfully',
      transaction
    });
  } catch (error) {
    console.error('Create transaction error:', error);
    res.status(500).json({ message: 'Server error while creating transaction' });
  }
});

// @route   GET /api/transactions/:id
// @desc    Get a specific transaction
// @access  Private
router.get('/:id', auth, async (req, res) => {
  try {
    const transaction = await Transaction.findOne({
      _id: req.params.id,
      user: req.user._id,
      isActive: true
    });

    if (!transaction) {
      return res.status(404).json({ message: 'Transaction not found' });
    }

    res.json({ transaction });
  } catch (error) {
    console.error('Get transaction error:', error);
    res.status(500).json({ message: 'Server error while fetching transaction' });
  }
});

// @route   PUT /api/transactions/:id
// @desc    Update a transaction
// @access  Private
router.put('/:id', auth, [
  body('type').optional().isIn(['income', 'expense']).withMessage('Type must be income or expense'),
  body('amount').optional().isFloat({ min: 0.01 }).withMessage('Amount must be greater than 0'),
  body('description').optional().trim().isLength({ min: 1, max: 200 }).withMessage('Description must be 1-200 characters'),
  body('category').optional().trim().isLength({ min: 1, max: 50 }).withMessage('Category must be 1-50 characters'),
  body('subcategory').optional().trim().isLength({ max: 50 }).withMessage('Subcategory cannot exceed 50 characters'),
  body('paymentMethod').optional().isIn(['cash', 'card', 'upi', 'netbanking', 'wallet', 'other']).withMessage('Invalid payment method'),
  body('tags').optional().isArray().withMessage('Tags must be an array'),
  body('location').optional().trim().isLength({ max: 100 }).withMessage('Location cannot exceed 100 characters'),
  body('notes').optional().trim().isLength({ max: 500 }).withMessage('Notes cannot exceed 500 characters'),
  body('date').optional().isISO8601().withMessage('Date must be valid ISO date'),
  body('isRecurring').optional().isBoolean().withMessage('isRecurring must be boolean'),
  body('recurringPattern').optional().isIn(['daily', 'weekly', 'monthly', 'yearly']).withMessage('Invalid recurring pattern')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const transaction = await Transaction.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id, isActive: true },
      req.body,
      { new: true, runValidators: true }
    );

    if (!transaction) {
      return res.status(404).json({ message: 'Transaction not found' });
    }

    res.json({
      message: 'Transaction updated successfully',
      transaction
    });
  } catch (error) {
    console.error('Update transaction error:', error);
    res.status(500).json({ message: 'Server error while updating transaction' });
  }
});

// @route   DELETE /api/transactions/:id
// @desc    Delete a transaction (soft delete)
// @access  Private
router.delete('/:id', auth, async (req, res) => {
  try {
    const transaction = await Transaction.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id, isActive: true },
      { isActive: false },
      { new: true }
    );

    if (!transaction) {
      return res.status(404).json({ message: 'Transaction not found' });
    }

    res.json({ message: 'Transaction deleted successfully' });
  } catch (error) {
    console.error('Delete transaction error:', error);
    res.status(500).json({ message: 'Server error while deleting transaction' });
  }
});

// @route   GET /api/transactions/stats/summary
// @desc    Get transaction summary statistics
// @access  Private
router.get('/stats/summary', auth, [
  query('startDate').optional().isISO8601().withMessage('Start date must be valid ISO date'),
  query('endDate').optional().isISO8601().withMessage('End date must be valid ISO date')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        message: 'Validation failed', 
        errors: errors.array() 
      });
    }

    const startDate = req.query.startDate ? new Date(req.query.startDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();

    const filter = {
      user: req.user._id,
      isActive: true,
      date: { $gte: startDate, $lte: endDate }
    };

    const [incomeStats, expenseStats, categoryStats] = await Promise.all([
      Transaction.aggregate([
        { $match: { ...filter, type: 'income' } },
        { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }
      ]),
      Transaction.aggregate([
        { $match: { ...filter, type: 'expense' } },
        { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } }
      ]),
      Transaction.aggregate([
        { $match: { ...filter, type: 'expense' } },
        { $group: { _id: '$category', total: { $sum: '$amount' }, count: { $sum: 1 } } },
        { $sort: { total: -1 } },
        { $limit: 10 }
      ])
    ]);

    const totalIncome = incomeStats[0]?.total || 0;
    const totalExpenses = expenseStats[0]?.total || 0;
    const incomeCount = incomeStats[0]?.count || 0;
    const expenseCount = expenseStats[0]?.count || 0;

    res.json({
      summary: {
        totalIncome,
        totalExpenses,
        netAmount: totalIncome - totalExpenses,
        incomeCount,
        expenseCount,
        totalTransactions: incomeCount + expenseCount
      },
      categoryBreakdown: categoryStats,
      period: {
        startDate,
        endDate
      }
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ message: 'Server error while fetching statistics' });
  }
});

module.exports = router;
