#!/usr/bin/env python3
"""
Simple FinTrack Website Server
"""

import http.server
import socketserver
import webbrowser
import os
import sys
from pathlib import Path

# Configuration
PORT = 8000
HOST = '127.0.0.1'

def main():
    """Main function to start the server"""
    
    # Change to the directory containing this script
    os.chdir(Path(__file__).parent)
    
    print("=" * 60)
    print("FinTrack Website Server")
    print("=" * 60)
    print(f"Serving directory: {os.getcwd()}")
    print(f"Server URL: http://{HOST}:{PORT}")
    print(f"Local network: http://localhost:{PORT}")
    print("=" * 60)
    print("Available pages:")
    print("   Home: http://localhost:8000/")
    print("   Features: http://localhost:8000/features.html")
    print("   How It Works: http://localhost:8000/how-it-works.html")
    print("   Demo: http://localhost:8000/demo.html")
    print("   About: http://localhost:8000/about.html")
    print("   Contact: http://localhost:8000/contact.html")
    print("=" * 60)
    print("Press Ctrl+C to stop the server")
    print("=" * 60)
    
    # Try to open browser automatically
    try:
        webbrowser.open(f'http://{HOST}:{PORT}')
        print("Opening browser automatically...")
    except Exception as e:
        print(f"Could not open browser automatically: {e}")
        print("Please manually open: http://localhost:8000")
    
    print()
    
    try:
        with socketserver.TCPServer((HOST, PORT), http.server.SimpleHTTPRequestHandler) as httpd:
            print(f"Server started successfully on http://{HOST}:{PORT}")
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped by user")
    except OSError as e:
        if e.errno == 98 or e.errno == 10048:  # Address already in use
            print(f"Port {PORT} is already in use!")
            print("Try:")
            print(f"   1. Kill existing process: netstat -ano | findstr :{PORT}")
            print("   2. Use different port: python simple_start.py --port 8001")
            print("   3. Wait a moment and try again")
        else:
            print(f"Error starting server: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

