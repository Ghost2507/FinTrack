# FinTrack Website - Troubleshooting Guide

## 🚀 Quick Start

### Method 1: Simple Python Server (Recommended)
```bash
python -m http.server 8000
```
Then open: http://localhost:8000

### Method 2: Using the Custom Server
```bash
python simple_start.py
```

### Method 3: Windows Batch File
Double-click `start_website.bat`

## 🔧 Common Issues & Solutions

### Issue 1: Website Shows Only Text (No Styling)

**Symptoms:**
- Only headings and links visible
- No colors, fonts, or layout
- Looks like plain HTML

**Solutions:**
1. **Hard Refresh**: Press `Ctrl + F5` (Windows) or `Cmd + Shift + R` (Mac)
2. **Clear Cache**: 
   - Press `F12` to open Developer Tools
   - Right-click refresh button → "Empty Cache and Hard Reload"
3. **Check Browser Console**: 
   - Press `F12` → Console tab
   - Look for red error messages
4. **Try Different Browser**: Chrome, Firefox, Edge
5. **Check Network Tab**: 
   - Press `F12` → Network tab
   - Refresh page and check if CSS/JS files load (should show 200 status)

### Issue 2: Server Won't Start

**Error**: "Port 8000 is already in use"

**Solutions:**
1. **Kill existing process**:
   ```bash
   # Windows
   netstat -ano | findstr :8000
   taskkill /PID <PID_NUMBER> /F
   
   # Or use different port
   python -m http.server 8001
   ```

2. **Wait and retry**: Sometimes the port takes a moment to free up

### Issue 3: Files Not Loading

**Check file structure**:
```
FinanceTracker/
├── index.html
├── features.html
├── how-it-works.html
├── demo.html
├── about.html
├── contact.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── test.html
```

### Issue 4: External Resources Not Loading

**If Bootstrap or Font Awesome icons don't show:**
- Check internet connection
- Try opening in incognito/private mode
- Some corporate networks block CDN resources

## 🌐 Testing the Website

### Step 1: Test Server
1. Go to: http://localhost:8000/test.html
2. You should see a green "SUCCESS" page
3. If this works, your server is running correctly

### Step 2: Test Main Website
1. Go to: http://localhost:8000/
2. You should see the FinTrack homepage with:
   - Green navigation bar
   - Styled hero section
   - Professional layout
   - Working buttons

### Step 3: Test All Pages
Navigate through all pages:
- Home: http://localhost:8000/
- Features: http://localhost:8000/features.html
- How It Works: http://localhost:8000/how-it-works.html
- Demo: http://localhost:8000/demo.html
- About: http://localhost:8000/about.html
- Contact: http://localhost:8000/contact.html

## 🎯 Expected Behavior

### Homepage Should Show:
- ✅ Green "FinTrack" logo in navigation
- ✅ Hero section with "Take Control of Your Money, Effortlessly"
- ✅ Styled buttons and cards
- ✅ Professional green and white theme
- ✅ Responsive navigation menu

### Demo Page Should Show:
- ✅ Interactive charts (Chart.js)
- ✅ Sample financial data
- ✅ Dashboard preview
- ✅ Budget progress bars

### All Pages Should Have:
- ✅ Consistent navigation
- ✅ Proper styling
- ✅ Working buttons
- ✅ Mobile-responsive design

## 🔍 Debugging Steps

### 1. Check Browser Console
- Press `F12`
- Look for errors in Console tab
- Common errors:
  - `Failed to load resource` (CSS/JS files)
  - `CORS policy` (cross-origin issues)
  - `404 Not Found` (missing files)

### 2. Check Network Tab
- Press `F12` → Network tab
- Refresh page
- Look for failed requests (red status codes)
- Check if CSS/JS files load successfully

### 3. Verify File Paths
Make sure you're running the server from the correct directory:
```bash
# Should show these files when you run 'dir':
index.html
features.html
css/
js/
```

## 🆘 Still Having Issues?

### Alternative Methods:

#### Method A: Use Node.js (if installed)
```bash
npx serve . -p 8000
```

#### Method B: Use PHP (if installed)
```bash
php -S localhost:8000
```

#### Method C: Direct File Opening
1. Right-click `index.html`
2. "Open with" → Browser
3. Note: External resources might not load this way

### Contact Support:
If none of these solutions work:
1. Check your Python version: `python --version`
2. Try a different port: `python -m http.server 8001`
3. Use a different browser
4. Check Windows Firewall/Antivirus settings

## ✅ Success Checklist

- [ ] Server starts without errors
- [ ] http://localhost:8000/test.html shows success page
- [ ] Main website loads with proper styling
- [ ] Navigation works between pages
- [ ] Demo page shows interactive charts
- [ ] Contact form displays correctly
- [ ] Mobile responsive design works

---

**Remember**: The website is a static site that should work with any modern web browser once the server is running correctly!

