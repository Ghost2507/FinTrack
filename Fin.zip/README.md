# FinTrack - Personal Finance Manager

A comprehensive personal finance management application built with Node.js, Express, MongoDB, and modern web technologies.

## Features

### 🔐 Secure Authentication
- User registration and login with JWT tokens
- Password hashing with bcrypt
- Session management and security middleware
- Input validation and sanitization

### 💰 Transaction Management
- Add, edit, and delete transactions
- Support for both income and expenses
- Categorization and tagging system
- Multiple payment methods
- Recurring transaction support

### 📊 Financial Dashboard
- Real-time financial overview
- Monthly budget tracking
- Visual charts and analytics
- Category-wise spending breakdown
- Monthly trend analysis

### 🛡️ Security Features
- Rate limiting to prevent abuse
- CORS protection
- Helmet.js security headers
- Input validation and sanitization
- Secure password requirements

## Technology Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM for MongoDB
- **JWT** - Authentication tokens
- **bcryptjs** - Password hashing
- **Express Validator** - Input validation
- **Helmet** - Security middleware
- **CORS** - Cross-origin resource sharing

### Frontend
- **HTML5** - Markup
- **CSS3** - Styling with Bootstrap 5
- **JavaScript (ES6+)** - Client-side logic
- **Chart.js** - Data visualization
- **Font Awesome** - Icons

## Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (v4.4 or higher)
- npm or yarn

### Quick Start

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd FinanceTracker
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   # Copy the example environment file
   cp config.env .env
   
   # Edit the .env file with your configuration
   # Update MONGODB_URI, JWT_SECRET, etc.
   ```

4. **Start MongoDB**
   ```bash
   # On Windows
   mongod --dbpath ./data/db
   
   # On macOS/Linux
   sudo systemctl start mongod
   ```

5. **Start the application**
   ```bash
   # Option 1: Use the batch file (Windows)
   start.bat
   
   # Option 2: Start manually
   npm start
   ```

6. **Access the application**
   - Frontend: http://localhost:8000
   - Backend API: http://localhost:3000

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `PUT /api/auth/profile` - Update user profile

### Transactions
- `GET /api/transactions` - Get user transactions
- `POST /api/transactions` - Create new transaction
- `GET /api/transactions/:id` - Get specific transaction
- `PUT /api/transactions/:id` - Update transaction
- `DELETE /api/transactions/:id` - Delete transaction
- `GET /api/transactions/stats/summary` - Get transaction statistics

### Dashboard
- `GET /api/users/dashboard` - Get dashboard data
- `GET /api/users/categories` - Get user categories

## Database Schema

### User Model
```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  monthlyBudget: Number,
  currency: String,
  isActive: Boolean,
  lastLogin: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Transaction Model
```javascript
{
  user: ObjectId (ref: User),
  type: String (income/expense),
  amount: Number,
  description: String,
  category: String,
  subcategory: String,
  paymentMethod: String,
  tags: [String],
  location: String,
  notes: String,
  date: Date,
  isRecurring: Boolean,
  recurringPattern: String,
  isActive: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

## Security Features

### Authentication & Authorization
- JWT-based authentication
- Password hashing with bcrypt (12 rounds)
- Token expiration (7 days)
- Protected routes with middleware

### Input Validation
- Server-side validation with express-validator
- Client-side validation
- SQL injection prevention
- XSS protection

### Rate Limiting
- 100 requests per 15 minutes per IP
- Separate limits for different endpoints
- Prevents brute force attacks

### Security Headers
- Helmet.js for security headers
- CORS configuration
- Content Security Policy
- X-Frame-Options protection

## Usage

### Getting Started
1. Visit http://localhost:8000
2. Click "Get Started" to create an account
3. Fill in your details and set a monthly budget
4. Start adding your transactions
5. View your financial dashboard for insights

### Adding Transactions
1. Click on your username in the navigation
2. Select "Add Transaction"
3. Choose transaction type (Income/Expense)
4. Fill in amount, description, and category
5. Select payment method and date
6. Add optional notes
7. Click "Add Transaction"

### Viewing Dashboard
1. Click "Dashboard" from the user menu
2. View your monthly financial overview
3. Check recent transactions
4. Analyze spending by category
5. Monitor monthly trends

## Development

### Project Structure
```
FinanceTracker/
├── models/           # Database models
├── routes/           # API routes
├── middleware/       # Custom middleware
├── js/              # Frontend JavaScript
├── css/             # Stylesheets
├── server.js        # Main server file
├── package.json     # Dependencies
└── README.md        # Documentation
```

### Running in Development Mode
```bash
# Install nodemon for auto-restart
npm install -g nodemon

# Start in development mode
npm run dev
```

### Environment Variables
```env
PORT=3000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/fintrack
JWT_SECRET=your-super-secret-jwt-key
FRONTEND_URL=http://localhost:8000
BCRYPT_ROUNDS=12
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue on GitHub
- Check the troubleshooting guide
- Review the API documentation

## Changelog

### v1.0.0
- Initial release
- User authentication system
- Transaction management
- Financial dashboard
- Security features
- Responsive design