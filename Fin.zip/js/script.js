// FinTrack JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add scroll effect to navbar
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
            }
        });
    }, observerOptions);

    // Observe elements for animation
    document.querySelectorAll('.feature-card, .step-card, .dashboard-preview').forEach(el => {
        observer.observe(el);
    });
});

// Authentication and Transaction Management Functions

// Show authentication modal
function showAuthModal() {
    const authModal = new bootstrap.Modal(document.getElementById('authModal'));
    authModal.show();
    showLoginForm();
}

// Show login form
function showLoginForm() {
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('authModalTitle').textContent = 'Sign In to FinTrack';
    document.querySelector('#showRegister').style.display = 'inline';
    document.querySelector('#showLogin').style.display = 'none';
}

// Show register form
function showRegisterForm() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
    document.getElementById('authModalTitle').textContent = 'Create Your FinTrack Account';
    document.querySelector('#showRegister').style.display = 'none';
    document.querySelector('#showLogin').style.display = 'inline';
}

// Show dashboard modal
function showDashboard() {
    const dashboardModal = new bootstrap.Modal(document.getElementById('dashboardModal'));
    dashboardModal.show();
    loadDashboard();
}

// Show transaction modal
function showTransactionModal() {
    const transactionModal = new bootstrap.Modal(document.getElementById('transactionModal'));
    transactionModal.show();
    // Set default date to now
    const now = new Date();
    const localDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    document.getElementById('transactionDate').value = localDateTime;
}

// Logout function
function logout() {
    authManager.logout();
    showNotification('You have been logged out successfully', 'info');
}

// Function to scroll to signup section (legacy support)
function scrollToSignup() {
    showAuthModal();
}

// Form validation and submission
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;

    const inputs = form.querySelectorAll('input[required], textarea[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('is-invalid');
            isValid = false;
        } else {
            input.classList.remove('is-invalid');
        }
    });

    // Email validation
    const emailInputs = form.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (input.value && !emailRegex.test(input.value)) {
            input.classList.add('is-invalid');
            isValid = false;
        }
    });

    return isValid;
}

// Handle contact form submission
function handleContactForm(event) {
    event.preventDefault();
    
    if (validateForm('contactForm')) {
        // Simulate form submission
        const submitBtn = event.target.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;
        
        setTimeout(() => {
            alert('Thank you for your message! We\'ll get back to you soon.');
            event.target.reset();
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }, 2000);
    }
}

// Mock data for demo charts
const mockChartData = {
    expenses: {
        labels: ['Food', 'Transport', 'Entertainment', 'Shopping', 'Bills'],
        data: [450, 200, 150, 300, 400]
    },
    monthly: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        income: [2500, 2600, 2400, 2800, 2700, 2900],
        expenses: [1800, 1900, 1700, 2100, 2000, 2200]
    }
};

// Initialize demo charts (if Chart.js is loaded)
function initDemoCharts() {
    if (typeof Chart === 'undefined') return;

    // Expense breakdown chart
    const expenseCtx = document.getElementById('expenseChart');
    if (expenseCtx) {
        new Chart(expenseCtx, {
            type: 'doughnut',
            data: {
                labels: mockChartData.expenses.labels,
                datasets: [{
                    data: mockChartData.expenses.data,
                    backgroundColor: [
                        '#28a745',
                        '#20c997',
                        '#17a2b8',
                        '#6f42c1',
                        '#fd7e14'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    // Monthly trend chart
    const monthlyCtx = document.getElementById('monthlyChart');
    if (monthlyCtx) {
        new Chart(monthlyCtx, {
            type: 'line',
            data: {
                labels: mockChartData.monthly.labels,
                datasets: [{
                    label: 'Income',
                    data: mockChartData.monthly.income,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Expenses',
                    data: mockChartData.monthly.expenses,
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

// Initialize charts when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Load Chart.js dynamically if needed
    if (document.getElementById('expenseChart') || document.getElementById('monthlyChart')) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
        script.onload = initDemoCharts;
        document.head.appendChild(script);
    }
});

// Add loading states to buttons
function addLoadingState(button) {
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
    button.disabled = true;
    
    return function removeLoadingState() {
        button.innerHTML = originalText;
        button.disabled = false;
    };
}

// Utility function for smooth animations
function animateValue(element, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const value = Math.floor(progress * (end - start) + start);
        element.textContent = value;
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// Animate counters on scroll
function animateCounters() {
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        animateValue(counter, 0, target, 2000);
    });
}

// Initialize counter animation when counters come into view
const counterObserver = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            animateCounters();
            counterObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

document.addEventListener('DOMContentLoaded', function() {
    const counterSection = document.querySelector('.counters-section');
    if (counterSection) {
        counterObserver.observe(counterSection);
    }

    // Initialize authentication and transaction handlers
    initializeAuthHandlers();
    initializeTransactionHandlers();
    checkAuthStatus();
});

// Initialize authentication event handlers
function initializeAuthHandlers() {
    // Login form submission
    document.getElementById('loginForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await handleLogin();
    });

    // Register form submission
    document.getElementById('registerForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await handleRegister();
    });

    // Form switching
    document.getElementById('showRegister').addEventListener('click', function(e) {
        e.preventDefault();
        showRegisterForm();
    });

    document.getElementById('showLogin').addEventListener('click', function(e) {
        e.preventDefault();
        showLoginForm();
    });
}

// Initialize transaction event handlers
function initializeTransactionHandlers() {
    // Transaction form submission
    document.getElementById('transactionForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        await handleTransactionSubmit();
    });
}

// Handle user login
async function handleLogin() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const submitBtn = document.getElementById('loginForm').querySelector('button[type="submit"]');
    
    const hideLoading = showLoading(submitBtn);
    
    try {
        const response = await apiClient.login({ email, password });
        
        authManager.setToken(response.token);
        authManager.setUser(response.user);
        authManager.redirectToDashboard();
        
        // Update UI
        document.getElementById('userName').textContent = response.user.name;
        
        // Close modal
        const authModal = bootstrap.Modal.getInstance(document.getElementById('authModal'));
        authModal.hide();
        
        showNotification('Welcome back! You have been logged in successfully.', 'success');
        
    } catch (error) {
        showNotification(error.message || 'Login failed. Please try again.', 'danger');
    } finally {
        hideLoading();
    }
}

// Handle user registration
async function handleRegister() {
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const monthlyBudget = parseFloat(document.getElementById('registerBudget').value) || 0;
    const currency = document.getElementById('registerCurrency').value;
    const submitBtn = document.getElementById('registerForm').querySelector('button[type="submit"]');
    
    const hideLoading = showLoading(submitBtn);
    
    try {
        const response = await apiClient.register({
            name,
            email,
            password,
            monthlyBudget,
            currency
        });
        
        authManager.setToken(response.token);
        authManager.setUser(response.user);
        authManager.redirectToDashboard();
        
        // Update UI
        document.getElementById('userName').textContent = response.user.name;
        
        // Close modal
        const authModal = bootstrap.Modal.getInstance(document.getElementById('authModal'));
        authModal.hide();
        
        showNotification('Account created successfully! Welcome to FinTrack!', 'success');
        
    } catch (error) {
        showNotification(error.message || 'Registration failed. Please try again.', 'danger');
    } finally {
        hideLoading();
    }
}

// Handle transaction submission
async function handleTransactionSubmit() {
    const transactionData = {
        type: document.getElementById('transactionType').value,
        amount: parseFloat(document.getElementById('transactionAmount').value),
        description: document.getElementById('transactionDescription').value,
        category: document.getElementById('transactionCategory').value,
        paymentMethod: document.getElementById('transactionPaymentMethod').value,
        date: new Date(document.getElementById('transactionDate').value),
        notes: document.getElementById('transactionNotes').value
    };
    
    const submitBtn = document.getElementById('transactionForm').querySelector('button[type="submit"]');
    const hideLoading = showLoading(submitBtn);
    
    try {
        await apiClient.createTransaction(transactionData);
        
        // Reset form
        document.getElementById('transactionForm').reset();
        
        // Close modal
        const transactionModal = bootstrap.Modal.getInstance(document.getElementById('transactionModal'));
        transactionModal.hide();
        
        showNotification('Transaction added successfully!', 'success');
        
        // Refresh dashboard if it's open
        if (document.getElementById('dashboardModal').classList.contains('show')) {
            loadDashboard();
        }
        
    } catch (error) {
        showNotification(error.message || 'Failed to add transaction. Please try again.', 'danger');
    } finally {
        hideLoading();
    }
}

// Load dashboard data
async function loadDashboard() {
    const dashboardContent = document.getElementById('dashboardContent');
    
    try {
        const data = await apiClient.getDashboardData();
        renderDashboard(data);
    } catch (error) {
        console.error('Dashboard load error:', error);
        dashboardContent.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Failed to load dashboard data. Please try again.
            </div>
        `;
    }
}

// Render dashboard content
function renderDashboard(data) {
    const dashboardContent = document.getElementById('dashboardContent');
    
    const currency = data.user.currency;
    const currencySymbol = getCurrencySymbol(currency);
    
    dashboardContent.innerHTML = `
        <div class="row mb-4">
            <div class="col-12">
                <h4>Welcome back, ${data.user.name}!</h4>
                <p class="text-muted">Here's your financial overview for this month</p>
            </div>
        </div>
        
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">Total Income</h6>
                                <h4>${currencySymbol}${data.currentMonth.totalIncome.toFixed(2)}</h4>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-arrow-up fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">Total Expenses</h6>
                                <h4>${currencySymbol}${data.currentMonth.totalExpenses.toFixed(2)}</h4>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-arrow-down fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card ${data.currentMonth.netAmount >= 0 ? 'bg-info' : 'bg-warning'} text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">Net Amount</h6>
                                <h4>${currencySymbol}${data.currentMonth.netAmount.toFixed(2)}</h4>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-balance-scale fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="card-title">Budget Used</h6>
                                <h4>${data.currentMonth.budgetUsedPercentage.toFixed(1)}%</h4>
                                <small>${currencySymbol}${data.currentMonth.budgetRemaining.toFixed(2)} remaining</small>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-chart-pie fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Recent Transactions</h5>
                    </div>
                    <div class="card-body">
                        ${renderRecentTransactions(data.recentTransactions, currencySymbol)}
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Category Breakdown</h5>
                    </div>
                    <div class="card-body">
                        ${renderCategoryBreakdown(data.categoryBreakdown, currencySymbol)}
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Monthly Trend</h5>
                        <button class="btn btn-success btn-sm" onclick="showTransactionModal()">
                            <i class="fas fa-plus me-1"></i>Add Transaction
                        </button>
                    </div>
                    <div class="card-body">
                        <canvas id="monthlyTrendChart" height="100"></canvas>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Initialize chart after content is rendered
    setTimeout(() => {
        initMonthlyTrendChart(data.monthlyTrend, currencySymbol);
    }, 100);
}

// Render recent transactions
function renderRecentTransactions(transactions, currencySymbol) {
    if (transactions.length === 0) {
        return '<p class="text-muted text-center">No transactions yet. <a href="#" onclick="showTransactionModal()">Add your first transaction</a></p>';
    }
    
    return transactions.map(transaction => `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <div class="d-flex align-items-center">
                <div class="me-3">
                    <i class="fas fa-${transaction.type === 'income' ? 'arrow-up text-success' : 'arrow-down text-danger'}"></i>
                </div>
                <div>
                    <div class="fw-bold">${transaction.description}</div>
                    <small class="text-muted">${transaction.category}</small>
                </div>
            </div>
            <div class="text-end">
                <div class="fw-bold ${transaction.type === 'income' ? 'text-success' : 'text-danger'}">
                    ${transaction.type === 'income' ? '+' : '-'}${currencySymbol}${transaction.amount.toFixed(2)}
                </div>
                <small class="text-muted">${new Date(transaction.date).toLocaleDateString()}</small>
            </div>
        </div>
    `).join('');
}

// Render category breakdown
function renderCategoryBreakdown(categories, currencySymbol) {
    if (categories.length === 0) {
        return '<p class="text-muted text-center">No expense data available</p>';
    }
    
    return categories.map(category => `
        <div class="d-flex justify-content-between align-items-center mb-2">
            <span>${category._id}</span>
            <span class="fw-bold">${currencySymbol}${category.total.toFixed(2)}</span>
        </div>
    `).join('');
}

// Initialize monthly trend chart
function initMonthlyTrendChart(data, currencySymbol) {
    const ctx = document.getElementById('monthlyTrendChart');
    if (!ctx) return;
    
    const labels = data.map(item => {
        const [year, month] = item.month.split('-');
        return new Date(year, month - 1).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    });
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Income',
                data: data.map(item => item.income),
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                tension: 0.4
            }, {
                label: 'Expenses',
                data: data.map(item => item.expenses),
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return currencySymbol + value.toFixed(0);
                        }
                    }
                }
            }
        }
    });
}

// Get currency symbol
function getCurrencySymbol(currency) {
    const symbols = {
        'INR': '₹',
        'USD': '$',
        'EUR': '€',
        'GBP': '£'
    };
    return symbols[currency] || '₹';
}

// Check authentication status on page load
function checkAuthStatus() {
    if (authManager.isAuthenticated) {
        authManager.redirectToDashboard();
        if (authManager.user) {
            document.getElementById('userName').textContent = authManager.user.name;
        }
    } else {
        authManager.redirectToLogin();
    }
}
