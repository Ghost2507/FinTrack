// API Configuration
const API_BASE_URL = 'http://localhost:3000/api';

// API Client Class
class APIClient {
  constructor() {
    this.baseURL = API_BASE_URL;
    this.token = localStorage.getItem('authToken');
  }

  // Set authentication token
  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('authToken', token);
    } else {
      localStorage.removeItem('authToken');
    }
  }

  // Get authentication headers
  getAuthHeaders() {
    const headers = {
      'Content-Type': 'application/json'
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  // Generic request method
  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: this.getAuthHeaders(),
      ...options
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Request failed');
      }

      return data;
    } catch (error) {
      console.error('API Request Error:', error);
      throw error;
    }
  }

  // Authentication methods
  async register(userData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  }

  async login(credentials) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
  }

  async getCurrentUser() {
    return this.request('/auth/me');
  }

  async updateProfile(profileData) {
    return this.request('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData)
    });
  }

  // Transaction methods
  async getTransactions(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/transactions?${queryString}`);
  }

  async createTransaction(transactionData) {
    return this.request('/transactions', {
      method: 'POST',
      body: JSON.stringify(transactionData)
    });
  }

  async updateTransaction(id, transactionData) {
    return this.request(`/transactions/${id}`, {
      method: 'PUT',
      body: JSON.stringify(transactionData)
    });
  }

  async deleteTransaction(id) {
    return this.request(`/transactions/${id}`, {
      method: 'DELETE'
    });
  }

  async getTransactionStats(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return this.request(`/transactions/stats/summary?${queryString}`);
  }

  // Dashboard methods
  async getDashboardData() {
    return this.request('/users/dashboard');
  }

  async getCategories() {
    return this.request('/users/categories');
  }
}

// Create global API client instance
const apiClient = new APIClient();

// Authentication state management
class AuthManager {
  constructor() {
    this.isAuthenticated = false;
    this.user = null;
    this.init();
  }

  init() {
    // Check if user is already logged in
    const token = localStorage.getItem('authToken');
    if (token) {
      this.setToken(token);
      this.getCurrentUser();
    }
  }

  setToken(token) {
    apiClient.setToken(token);
    this.isAuthenticated = !!token;
  }

  setUser(user) {
    this.user = user;
    this.isAuthenticated = true;
  }

  logout() {
    this.user = null;
    this.isAuthenticated = false;
    apiClient.setToken(null);
    this.redirectToLogin();
  }

  async getCurrentUser() {
    try {
      const response = await apiClient.getCurrentUser();
      this.setUser(response.user);
      return response.user;
    } catch (error) {
      console.error('Failed to get current user:', error);
      this.logout();
      throw error;
    }
  }

  redirectToLogin() {
    // Hide authenticated content and show login form
    const authContent = document.querySelectorAll('.auth-required');
    const loginContent = document.querySelectorAll('.login-required');
    
    authContent.forEach(el => el.style.display = 'none');
    loginContent.forEach(el => el.style.display = 'block');
  }

  redirectToDashboard() {
    // Show authenticated content and hide login form
    const authContent = document.querySelectorAll('.auth-required');
    const loginContent = document.querySelectorAll('.login-required');
    
    authContent.forEach(el => el.style.display = 'block');
    loginContent.forEach(el => el.style.display = 'none');
  }
}

// Create global auth manager instance
const authManager = new AuthManager();

// Utility functions
function showNotification(message, type = 'info') {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
  notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
  notification.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  `;
  
  document.body.appendChild(notification);
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.parentNode.removeChild(notification);
    }
  }, 5000);
}

function showLoading(element) {
  const originalContent = element.innerHTML;
  element.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
  element.disabled = true;
  
  return function hideLoading() {
    element.innerHTML = originalContent;
    element.disabled = false;
  };
}

// Export for use in other scripts
window.apiClient = apiClient;
window.authManager = authManager;
window.showNotification = showNotification;
window.showLoading = showLoading;
