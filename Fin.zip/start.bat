@echo off
echo Starting FinTrack Finance Tracker...
echo.

echo Installing dependencies...
call npm install

echo.
echo Starting MongoDB (if not running)...
start "MongoDB" cmd /k "mongod --dbpath ./data/db"

echo.
echo Starting FinTrack Server...
start "FinTrack Server" cmd /k "node server.js"

echo.
echo Starting Frontend Server...
start "FinTrack Frontend" cmd /k "npx serve . -p 8000"

echo.
echo FinTrack is starting up...
echo Backend: http://localhost:3000
echo Frontend: http://localhost:8000
echo.
echo Press any key to exit...
pause > nul
