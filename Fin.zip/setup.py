#!/usr/bin/env python3
"""
FinTrack Website Setup Script
Checks environment and sets up the website for development
"""

import os
import sys
import subprocess
import webbrowser
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    version = sys.version_info
    print(f"🐍 Python version: {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 6):
        print("❌ Python 3.6+ required!")
        return False
    
    print("✅ Python version is compatible")
    return True

def check_files():
    """Check if all required files exist"""
    required_files = [
        'index.html',
        'features.html',
        'how-it-works.html',
        'demo.html',
        'about.html',
        'contact.html',
        'css/style.css',
        'js/script.js'
    ]
    
    print("📁 Checking required files...")
    missing_files = []
    
    for file_path in required_files:
        if not Path(file_path).exists():
            missing_files.append(file_path)
        else:
            print(f"   ✅ {file_path}")
    
    if missing_files:
        print(f"❌ Missing files: {missing_files}")
        return False
    
    print("✅ All required files are present")
    return True

def check_dependencies():
    """Check if required dependencies are available"""
    print("📦 Checking dependencies...")
    
    # Check if we can import required modules
    try:
        import http.server
        import socketserver
        import webbrowser
        print("   ✅ Standard library modules available")
    except ImportError as e:
        print(f"   ❌ Missing standard library: {e}")
        return False
    
    return True

def create_launcher_scripts():
    """Create launcher scripts for different operating systems"""
    print("🚀 Creating launcher scripts...")
    
    # Windows batch file
    windows_script = """@echo off
title FinTrack Website Server
echo Starting FinTrack Website...
echo.
python start_server.py
pause
"""
    
    with open('start_fintrack.bat', 'w') as f:
        f.write(windows_script)
    
    # Unix/Linux shell script
    unix_script = """#!/bin/bash
echo "Starting FinTrack Website..."
python3 start_server.py
"""
    
    with open('start_fintrack.sh', 'w') as f:
        f.write(unix_script)
    
    # Make shell script executable on Unix systems
    try:
        os.chmod('start_fintrack.sh', 0o755)
    except:
        pass  # Windows doesn't support chmod
    
    print("   ✅ Created start_fintrack.bat (Windows)")
    print("   ✅ Created start_fintrack.sh (Unix/Linux)")

def main():
    """Main setup function"""
    print("=" * 60)
    print("🎯 FinTrack Website Setup")
    print("=" * 60)
    
    # Change to script directory
    script_dir = Path(__file__).parent
    os.chdir(script_dir)
    print(f"📁 Working directory: {os.getcwd()}")
    print()
    
    # Run checks
    checks = [
        ("Python Version", check_python_version),
        ("Required Files", check_files),
        ("Dependencies", check_dependencies)
    ]
    
    all_passed = True
    for check_name, check_func in checks:
        print(f"🔍 {check_name} Check:")
        if not check_func():
            all_passed = False
        print()
    
    if not all_passed:
        print("❌ Setup failed! Please fix the issues above.")
        return False
    
    # Create launcher scripts
    create_launcher_scripts()
    print()
    
    # Success message
    print("=" * 60)
    print("🎉 Setup Complete!")
    print("=" * 60)
    print("🚀 To start the website:")
    print("   Windows: Double-click 'start_fintrack.bat'")
    print("   Unix/Linux: Run './start_fintrack.sh'")
    print("   Manual: python start_server.py")
    print()
    print("🌐 Website will be available at: http://localhost:8000")
    print("=" * 60)
    
    # Ask if user wants to start now
    try:
        response = input("🚀 Start the website now? (y/n): ").lower().strip()
        if response in ['y', 'yes']:
            print("Starting website...")
            subprocess.run([sys.executable, 'start_server.py'])
    except KeyboardInterrupt:
        print("\n👋 Setup complete! Run 'python start_server.py' when ready.")
    
    return True

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n👋 Setup cancelled by user.")
    except Exception as e:
        print(f"❌ Setup error: {e}")
        sys.exit(1)

