require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Transaction = require('../models/Transaction');

async function connectToDatabase() {
  const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/fintrack';
  await mongoose.connect(mongoUri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  // Ensure indexes defined in schemas are in place
  await Promise.all([
    User.syncIndexes(),
    Transaction.syncIndexes(),
  ]);
}

async function seed() {
  try {
    await connectToDatabase();

    const demoEmail = 'demo@fintrack.local';

    let user = await User.findOne({ email: demoEmail });
    if (!user) {
      user = new User({
        name: 'Demo User',
        email: demoEmail,
        password: 'password123',
        monthlyBudget: 50000,
        currency: 'INR',
      });
      await user.save();
      console.log(`Created demo user: ${demoEmail} (password: password123)`);
    } else {
      console.log(`Demo user already exists: ${demoEmail}`);
    }

    const existingTxCount = await Transaction.countDocuments({ user: user._id });
    if (existingTxCount === 0) {
      const now = new Date();
      const sampleTransactions = [
        {
          user: user._id,
          type: 'income',
          amount: 80000,
          description: 'Salary',
          category: 'Income',
          paymentMethod: 'netbanking',
          date: new Date(now.getFullYear(), now.getMonth(), 1),
        },
        {
          user: user._id,
          type: 'expense',
          amount: 1200,
          description: 'Groceries',
          category: 'Food',
          paymentMethod: 'card',
          date: new Date(now.getFullYear(), now.getMonth(), 3),
        },
        {
          user: user._id,
          type: 'expense',
          amount: 2500,
          description: 'Electricity Bill',
          category: 'Utilities',
          paymentMethod: 'upi',
          date: new Date(now.getFullYear(), now.getMonth(), 5),
        },
        {
          user: user._id,
          type: 'expense',
          amount: 600,
          description: 'Coffee with friends',
          category: 'Leisure',
          paymentMethod: 'wallet',
          date: new Date(now.getFullYear(), now.getMonth(), 7),
        },
      ];

      await Transaction.insertMany(sampleTransactions);
      console.log('Inserted sample transactions');
    } else {
      console.log(`Found ${existingTxCount} existing transactions for demo user, skipping sample insert`);
    }

    console.log('Seed complete.');
  } catch (err) {
    console.error('Seed error:', err);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

seed();


